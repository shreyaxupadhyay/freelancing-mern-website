import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { BarChart3, Users, Briefcase, DollarSign, TrendingUp, Clock, Star, ArrowRight } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { profile } = useAuth();

  const freelancerStats = [
    { label: 'Active Projects', value: '3', icon: Briefcase, color: 'text-primary-600', bg: 'bg-primary-100' },
    { label: 'Total Earnings', value: '$12,450', icon: DollarSign, color: 'text-accent-600', bg: 'bg-accent-100' },
    { label: 'Hours Worked', value: '284', icon: Clock, color: 'text-secondary-600', bg: 'bg-secondary-100' },
    { label: 'Client Rating', value: '4.9', icon: Star, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  ];

  const clientStats = [
    { label: 'Active Projects', value: '5', icon: Briefcase, color: 'text-primary-600', bg: 'bg-primary-100' },
    { label: 'Total Spent', value: '$28,750', icon: DollarSign, color: 'text-accent-600', bg: 'bg-accent-100' },
    { label: 'Freelancers Hired', value: '12', icon: Users, color: 'text-secondary-600', bg: 'bg-secondary-100' },
    { label: 'Success Rate', value: '96%', icon: TrendingUp, color: 'text-yellow-600', bg: 'bg-yellow-100' },
  ];

  const recentProjects = [
    {
      title: 'E-commerce Website Development',
      client: 'TechStart Inc.',
      status: 'In Progress',
      deadline: '2025-02-15',
      budget: '$3,500',
      progress: 65
    },
    {
      title: 'Mobile App UI/UX Design',
      client: 'Creative Studio',
      status: 'Review',
      deadline: '2025-01-28',
      budget: '$2,200',
      progress: 90
    },
    {
      title: 'Brand Identity Package',
      client: 'StartupXYZ',
      status: 'Completed',
      deadline: '2025-01-20',
      budget: '$1,800',
      progress: 100
    },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Progress': return 'bg-blue-100 text-blue-800';
      case 'Review': return 'bg-yellow-100 text-yellow-800';
      case 'Completed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const stats = profile?.user_type === 'freelancer' ? freelancerStats : clientStats;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {profile?.full_name || 'User'}!
          </h1>
          <p className="text-gray-600 mt-2">
            {profile?.user_type === 'freelancer' 
              ? "Here's what's happening with your freelancing career" 
              : "Manage your projects and find the perfect freelancers"}
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <div 
              key={index} 
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300 animate-slide-up"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg ${stat.bg}`}>
                  <stat.icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Recent Projects */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-gray-900">Recent Projects</h2>
                <button className="text-primary-600 hover:text-primary-700 font-medium text-sm flex items-center">
                  View All
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>
              </div>

              <div className="space-y-4">
                {recentProjects.map((project, index) => (
                  <div 
                    key={index} 
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-1">{project.title}</h3>
                        <p className="text-sm text-gray-600">{project.client}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(project.status)}`}>
                        {project.status}
                      </span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span>Due: {new Date(project.deadline).toLocaleDateString()}</span>
                      <span className="font-semibold text-gray-900">{project.budget}</span>
                    </div>

                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-primary-600 h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${project.progress}%` }}
                      ></div>
                    </div>
                    <div className="text-xs text-gray-600 mt-1 text-right">
                      {project.progress}% complete
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Actions & Activity */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
              <div className="space-y-3">
                {profile?.user_type === 'freelancer' ? (
                  <>
                    <button className="w-full bg-primary-600 text-white py-3 px-4 rounded-lg hover:bg-primary-700 transition-colors duration-200 font-medium">
                      Browse Projects
                    </button>
                    <button className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200 font-medium">
                      Update Portfolio
                    </button>
                    <button className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200 font-medium">
                      View Proposals
                    </button>
                  </>
                ) : (
                  <>
                    <button className="w-full bg-primary-600 text-white py-3 px-4 rounded-lg hover:bg-primary-700 transition-colors duration-200 font-medium">
                      Post New Project
                    </button>
                    <button className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200 font-medium">
                      Browse Freelancers
                    </button>
                    <button className="w-full border border-gray-300 text-gray-700 py-3 px-4 rounded-lg hover:bg-gray-50 transition-colors duration-200 font-medium">
                      Review Proposals
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">Project milestone completed</p>
                    <p className="text-xs text-gray-500">2 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">New proposal received</p>
                    <p className="text-xs text-gray-500">5 hours ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">Payment processed</p>
                    <p className="text-xs text-gray-500">1 day ago</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-900">Profile viewed 15 times</p>
                    <p className="text-xs text-gray-500">2 days ago</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;