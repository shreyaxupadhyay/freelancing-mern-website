import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          user_id: string;
          full_name: string;
          avatar_url?: string;
          user_type: 'freelancer' | 'client';
          title?: string;
          bio?: string;
          skills?: string[];
          hourly_rate?: number;
          location?: string;
          portfolio_urls?: string[];
          rating?: number;
          total_reviews?: number;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['profiles']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['profiles']['Insert']>;
      };
      projects: {
        Row: {
          id: string;
          client_id: string;
          title: string;
          description: string;
          budget_min: number;
          budget_max: number;
          skills_required: string[];
          project_type: 'fixed' | 'hourly';
          status: 'open' | 'in_progress' | 'completed' | 'cancelled';
          deadline?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['projects']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['projects']['Insert']>;
      };
      proposals: {
        Row: {
          id: string;
          project_id: string;
          freelancer_id: string;
          cover_letter: string;
          proposed_rate: number;
          estimated_duration: string;
          status: 'pending' | 'accepted' | 'rejected';
          created_at: string;
          updated_at: string;
        };
        Insert: Omit<Database['public']['Tables']['proposals']['Row'], 'id' | 'created_at' | 'updated_at'>;
        Update: Partial<Database['public']['Tables']['proposals']['Insert']>;
      };
    };
  };
};