/*
  # Create profiles table for freelance platform

  1. New Tables
    - `profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users, unique)
      - `full_name` (text, required)
      - `avatar_url` (text, optional)
      - `user_type` (text, required - 'freelancer' or 'client')
      - `title` (text, optional)
      - `bio` (text, optional)
      - `skills` (text array, optional)
      - `hourly_rate` (numeric, optional)
      - `location` (text, optional)
      - `portfolio_urls` (text array, optional)
      - `rating` (numeric, optional, default 0)
      - `total_reviews` (integer, optional, default 0)
      - `created_at` (timestamp with timezone, default now())
      - `updated_at` (timestamp with timezone, default now())

  2. Security
    - Enable RLS on `profiles` table
    - Add policy for authenticated users to insert their own profile
    - Add policy for authenticated users to read their own profile
    - Add policy for authenticated users to update their own profile
    - Add policy for public read access to freelancer profiles
*/

CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  full_name text NOT NULL,
  avatar_url text,
  user_type text NOT NULL CHECK (user_type IN ('freelancer', 'client')),
  title text,
  bio text,
  skills text[],
  hourly_rate numeric,
  location text,
  portfolio_urls text[],
  rating numeric DEFAULT 0,
  total_reviews integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Policy for users to insert their own profile
CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Policy for users to read their own profile
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Policy for users to update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Policy for public read access to freelancer profiles (for browsing)
CREATE POLICY "Public can read freelancer profiles"
  ON profiles
  FOR SELECT
  TO anon, authenticated
  USING (user_type = 'freelancer');

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();