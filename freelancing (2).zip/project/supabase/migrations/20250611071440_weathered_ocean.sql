/*
  # Create proposals table for freelance platform

  1. New Tables
    - `proposals`
      - `id` (uuid, primary key)
      - `project_id` (uuid, foreign key to projects)
      - `freelancer_id` (uuid, foreign key to profiles)
      - `cover_letter` (text, required)
      - `proposed_rate` (numeric, required)
      - `estimated_duration` (text, required)
      - `status` (text, required - 'pending', 'accepted', 'rejected')
      - `created_at` (timestamp with timezone, default now())
      - `updated_at` (timestamp with timezone, default now())

  2. Security
    - Enable RLS on `proposals` table
    - Add policy for freelancers to create proposals
    - Add policy for freelancers to read their own proposals
    - Add policy for clients to read proposals for their projects
    - Add policy for clients to update proposal status
*/

CREATE TABLE IF NOT EXISTS proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  freelancer_id uuid REFERENCES profiles(user_id) ON DELETE CASCADE NOT NULL,
  cover_letter text NOT NULL,
  proposed_rate numeric NOT NULL,
  estimated_duration text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(project_id, freelancer_id)
);

-- Enable RLS
ALTER TABLE proposals ENABLE ROW LEVEL SECURITY;

-- Policy for freelancers to create proposals
CREATE POLICY "Freelancers can create proposals"
  ON proposals
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = freelancer_id AND
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE user_id = auth.uid() AND user_type = 'freelancer'
    )
  );

-- Policy for freelancers to read their own proposals
CREATE POLICY "Freelancers can read own proposals"
  ON proposals
  FOR SELECT
  TO authenticated
  USING (auth.uid() = freelancer_id);

-- Policy for clients to read proposals for their projects
CREATE POLICY "Clients can read proposals for own projects"
  ON proposals
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects 
      WHERE projects.id = proposals.project_id AND projects.client_id = auth.uid()
    )
  );

-- Policy for clients to update proposal status
CREATE POLICY "Clients can update proposal status"
  ON proposals
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM projects 
      WHERE projects.id = proposals.project_id AND projects.client_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM projects 
      WHERE projects.id = proposals.project_id AND projects.client_id = auth.uid()
    )
  );

-- Create updated_at trigger for proposals
CREATE TRIGGER update_proposals_updated_at
  BEFORE UPDATE ON proposals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();