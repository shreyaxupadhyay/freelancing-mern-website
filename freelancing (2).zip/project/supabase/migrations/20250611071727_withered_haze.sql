/*
  # Fix RLS policy for profiles table

  1. Security Changes
    - Drop the existing INSERT policy that uses incorrect `uid()` function
    - Create new INSERT policy using correct `auth.uid()` function
    - Drop the existing UPDATE policy that uses incorrect `uid()` function  
    - Create new UPDATE policy using correct `auth.uid()` function
    - Drop the existing SELECT policy for own profile that uses incorrect `uid()` function
    - Create new SELECT policy using correct `auth.uid()` function

  This fixes the RLS policy violation error that occurs during user signup.
*/

-- Drop existing policies that use incorrect uid() function
DROP POLICY IF EXISTS "Users can insert own profile" ON profiles;
DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
DROP POLICY IF EXISTS "Users can read own profile" ON profiles;

-- Create corrected INSERT policy using auth.uid()
CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create corrected UPDATE policy using auth.uid()
CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create corrected SELECT policy for own profile using auth.uid()
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);