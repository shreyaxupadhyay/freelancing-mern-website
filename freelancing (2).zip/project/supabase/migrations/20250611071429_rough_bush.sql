/*
  # Create projects table for freelance platform

  1. New Tables
    - `projects`
      - `id` (uuid, primary key)
      - `client_id` (uuid, foreign key to profiles)
      - `title` (text, required)
      - `description` (text, required)
      - `budget_min` (numeric, required)
      - `budget_max` (numeric, required)
      - `skills_required` (text array, required)
      - `project_type` (text, required - 'fixed' or 'hourly')
      - `status` (text, required - 'open', 'in_progress', 'completed', 'cancelled')
      - `deadline` (timestamp with timezone, optional)
      - `created_at` (timestamp with timezone, default now())
      - `updated_at` (timestamp with timezone, default now())

  2. Security
    - Enable RLS on `projects` table
    - Add policy for clients to create projects
    - Add policy for clients to read/update their own projects
    - Add policy for public read access to open projects
*/

CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid REFERENCES profiles(user_id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  budget_min numeric NOT NULL,
  budget_max numeric NOT NULL,
  skills_required text[] NOT NULL,
  project_type text NOT NULL CHECK (project_type IN ('fixed', 'hourly')),
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'in_progress', 'completed', 'cancelled')),
  deadline timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

-- Policy for clients to create projects
CREATE POLICY "Clients can create projects"
  ON projects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = client_id AND
    EXISTS (
      SELECT 1 FROM profiles 
      WHERE user_id = auth.uid() AND user_type = 'client'
    )
  );

-- Policy for clients to read their own projects
CREATE POLICY "Clients can read own projects"
  ON projects
  FOR SELECT
  TO authenticated
  USING (auth.uid() = client_id);

-- Policy for clients to update their own projects
CREATE POLICY "Clients can update own projects"
  ON projects
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = client_id)
  WITH CHECK (auth.uid() = client_id);

-- Policy for public read access to open projects
CREATE POLICY "Public can read open projects"
  ON projects
  FOR SELECT
  TO anon, authenticated
  USING (status = 'open');

-- Create updated_at trigger for projects
CREATE TRIGGER update_projects_updated_at
  BEFORE UPDATE ON projects
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();